<!-- BEGIN:ludicord-agent-rules -->
# Ludicord 4.0

Before changing a Ludicord Activity, read the relevant version-matched guide in `dist/docs/` and the reusable skill at `dist/skills/ludicord/SKILL.md`. Treat the installed declarations, project configuration, and generated `ludicord.generated.d.ts` as the API authority.

Ludicord's unified router uses `page.tsx` for pages, `route.ts` for HTTP methods, `socket.ts` for WebSockets, and `embed.tsx` for hash routes owned by their nearest ancestor page. Use at most one route file per directory.

Default to one root page and ordinary embeds. Create independent pathname scopes only for a large project's separate surfaces or an important requirement for distinct URLs, shells, or provider lifetimes; explain the requirement before adding that architecture.

Keep secrets and authorization on the server. Run the relevant lint, type, route, production-build, and behavior checks before finishing.

Register trusted compiler extensions through `plugins` in `ludicord.config.mjs`. Read `dist/docs/plugins.md` before using `definePlugin()` or the official `wasm()` plugin; do not add a Vite config.
<!-- END:ludicord-agent-rules -->
